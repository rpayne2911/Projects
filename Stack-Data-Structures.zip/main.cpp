#include <iostream>
#include "StackType.h"

using namespace std;


int main() {
  StackType royceStack;
// 8a
  for(int i = 0; i < 5; i++){
  royceStack.Push(i);
  }

  int var1 = royceStack.Top();
  cout << var1 << endl;

  royceStack.Pop();
  int var2 = royceStack.Top();
  cout << var2 << endl;
  royceStack.Pop();
// 8b
  int bottom = royceStack.Top();
  cout << bottom << endl;
  royceStack.Pop();
//8c
  int bottom2 = royceStack.Top();

//8d
  for(int i = 0; i < 2; i++){
  royceStack.Push(i);
  }

  int royceArray[2];

  for(int i = 0; i < 2; i++){
    int tempVar = royceStack.Top();
    royceArray[i] = tempVar;
    royceStack.Pop();
  }
  StackType royceStack2;

  for(int i = 2; i > -1; i--){
    royceStack2.Push(royceArray[i]);
    cout << royceStack2.Top() << endl;
  }
}